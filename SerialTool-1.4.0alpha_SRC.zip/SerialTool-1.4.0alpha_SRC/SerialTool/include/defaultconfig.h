#ifndef DEFAULTCONFIG_H
#define DEFAULTCONFIG_H

class QString;

void syncDefaultConfig(const QString &iniName);

#endif // DEFAULTCONFIG_H
